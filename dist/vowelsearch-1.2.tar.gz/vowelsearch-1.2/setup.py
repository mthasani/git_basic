# -*- coding: utf-8 -*-
"""
Created on Fri Apr 16 17:44:24 2021

@author: mohammadtaher
"""

from setuptools import setup

setup(name= 'vowelsearch', version= 1.2, py_module= ['vowelsearch'])